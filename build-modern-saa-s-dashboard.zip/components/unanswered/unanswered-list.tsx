"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Search, Mail, Phone, CheckCircle, AlertTriangle } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { StatusBadge } from "@/components/ui/status-badge"
import { cn } from "@/lib/utils"
import type { UnansweredQuestion } from "@/types"

interface UnansweredListProps {
  questions: UnansweredQuestion[]
}

const statusBorderColors = {
  pending: "border-l-red-500",
  contacted: "border-l-orange-500",
  resolved: "border-l-emerald-500",
}

export function UnansweredList({ questions }: UnansweredListProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [items, setItems] = useState(questions)

  const filteredItems = items.filter((q) =>
    q.question.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const pendingCount = items.filter((q) => q.status === "pending").length

  const handleMarkResolved = (id: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status: "resolved" as const } : item
      )
    )
  }

  const handleContactUser = (id: string) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status: "contacted" as const } : item
      )
    )
  }

  return (
    <div className="space-y-6">
      {/* Header with search and pending count */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 sm:max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex items-center gap-2 rounded-full bg-red-100 px-4 py-2 text-red-700">
          <AlertTriangle className="h-4 w-4" />
          <span className="text-sm font-medium">{pendingCount} pending</span>
        </div>
      </div>

      {/* Questions List */}
      <div className="space-y-4">
        {filteredItems.map((question, index) => (
          <motion.div
            key={question.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={cn(
              "rounded-xl border border-border bg-card p-5 transition-shadow hover:shadow-md border-l-4",
              statusBorderColors[question.status]
            )}
          >
            <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
              {/* Question Content */}
              <div className="flex-1 space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-base font-semibold">{question.question}</h3>
                  <StatusBadge status={question.status} />
                </div>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
                  <span>{question.sessionId}</span>
                  <span>·</span>
                  <span className="rounded-md bg-muted px-2 py-0.5 text-xs font-medium">
                    {question.department}
                  </span>
                  <span>·</span>
                  {question.userEmail ? (
                    <span className="flex items-center gap-1">
                      <Mail className="h-3.5 w-3.5" />
                      {question.userEmail}
                    </span>
                  ) : question.userPhone ? (
                    <span className="flex items-center gap-1">
                      <Phone className="h-3.5 w-3.5" />
                      {question.userPhone}
                    </span>
                  ) : null}
                  <span>·</span>
                  <span>{question.timestamp}</span>
                </div>
              </div>

              {/* Actions */}
              {question.status !== "resolved" && (
                <div className="flex items-center gap-2">
                  {question.status === "pending" && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleContactUser(question.id)}
                      className="gap-2"
                    >
                      <Mail className="h-4 w-4" />
                      Contact User
                    </Button>
                  )}
                  <Button
                    size="sm"
                    onClick={() => handleMarkResolved(question.id)}
                    className="gap-2 bg-emerald-600 hover:bg-emerald-700"
                  >
                    <CheckCircle className="h-4 w-4" />
                    Mark Resolved
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
