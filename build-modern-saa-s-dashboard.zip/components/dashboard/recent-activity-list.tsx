"use client"

import { motion } from "framer-motion"
import { MessageSquare, CheckCircle, AlertCircle, Clock } from "lucide-react"
import { cn } from "@/lib/utils"
import type { RecentActivity } from "@/types"

interface RecentActivityListProps {
  activities: RecentActivity[]
}

const statusConfig = {
  answered: {
    label: "Answered",
    color: "bg-emerald-100 text-emerald-700 border-emerald-200",
    icon: CheckCircle,
  },
  unanswered: {
    label: "Unanswered",
    color: "bg-red-100 text-red-700 border-red-200",
    icon: AlertCircle,
  },
  pending: {
    label: "Pending",
    color: "bg-amber-100 text-amber-700 border-amber-200",
    icon: Clock,
  },
}

export function RecentActivityList({ activities }: RecentActivityListProps) {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="flex items-center justify-between border-b border-border p-6">
        <div>
          <h3 className="text-lg font-semibold">Recent Activity</h3>
          <p className="text-sm text-muted-foreground">Latest chatbot interactions</p>
        </div>
        <button className="text-sm font-medium text-primary hover:underline">
          View all
        </button>
      </div>
      <div className="divide-y divide-border">
        {activities.map((activity, index) => {
          const status = statusConfig[activity.status]
          return (
            <motion.div
              key={activity.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-center justify-between gap-4 p-4 transition-colors hover:bg-muted/50"
            >
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-muted">
                  <MessageSquare className="h-5 w-5 text-muted-foreground" />
                </div>
                <div className="min-w-0">
                  <p className="truncate font-medium">{activity.question}</p>
                  <p className="text-sm text-muted-foreground">
                    {activity.userId} · {activity.department} · {activity.timestamp}
                  </p>
                </div>
              </div>
              <div
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium",
                  status.color
                )}
              >
                <status.icon className="h-3 w-3" />
                {status.label}
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  )
}
