"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"
import type { ResponseStatus } from "@/types"

interface ResponseStatusChartProps {
  data: ResponseStatus[]
}

export function ResponseStatusChart({ data }: ResponseStatusChartProps) {
  const total = data.reduce((sum, item) => sum + item.value, 0)

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold">Response Status</h3>
        <p className="text-sm text-muted-foreground">Breakdown of question statuses</p>
      </div>
      <div className="h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={2}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                boxShadow: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
              }}
              formatter={(value: number, name: string) => [
                `${value.toLocaleString()} (${Math.round((value / total) * 100)}%)`,
                name,
              ]}
            />
            <Legend
              layout="vertical"
              verticalAlign="middle"
              align="right"
              formatter={(value, entry) => {
                const item = data.find((d) => d.name === value)
                if (!item) return value
                const percentage = Math.round((item.value / total) * 100)
                return (
                  <span className="text-sm">
                    <span className="font-medium">{value}</span>
                    <span className="ml-2 text-muted-foreground">
                      {item.value.toLocaleString()} ({percentage}%)
                    </span>
                  </span>
                )
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
