import { cn } from "@/lib/utils"

interface StatusBadgeProps {
  status: "answered" | "unanswered" | "pending" | "contacted" | "resolved"
  className?: string
}

const statusConfig = {
  answered: {
    label: "Answered",
    className: "bg-emerald-100 text-emerald-700 border-emerald-200",
  },
  unanswered: {
    label: "Unanswered",
    className: "bg-red-100 text-red-700 border-red-200",
  },
  pending: {
    label: "Pending",
    className: "bg-amber-100 text-amber-700 border-amber-200",
  },
  contacted: {
    label: "Contacted",
    className: "bg-orange-100 text-orange-700 border-orange-200",
  },
  resolved: {
    label: "Resolved",
    className: "bg-emerald-100 text-emerald-700 border-emerald-200",
  },
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = statusConfig[status]

  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium",
        config.className,
        className
      )}
    >
      {config.label}
    </span>
  )
}
