"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Save, User, Mail, Database, Key } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import type { AdminSettings } from "@/types"

interface SettingsFormProps {
  initialSettings: AdminSettings
}

export function SettingsForm({ initialSettings }: SettingsFormProps) {
  const [settings, setSettings] = useState(initialSettings)
  const [isSaving, setIsSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState("")

  const handleChange = (field: keyof AdminSettings, value: string) => {
    setSettings((prev) => ({ ...prev, [field]: value }))
  }

  const handleSave = async () => {
    setIsSaving(true)
    setSaveMessage("")

    // Simulate save operation
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setIsSaving(false)
    setSaveMessage("Settings saved successfully!")
    setTimeout(() => setSaveMessage(""), 3000)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="mx-auto max-w-2xl space-y-6"
    >
      {/* Admin Information */}
      <div className="rounded-xl border border-border bg-card p-6">
        <h3 className="mb-6 text-lg font-semibold">Admin Information</h3>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="adminName" className="flex items-center gap-2">
              <User className="h-4 w-4 text-muted-foreground" />
              Admin Name
            </Label>
            <Input
              id="adminName"
              value={settings.adminName}
              onChange={(e) => handleChange("adminName", e.target.value)}
              placeholder="Enter admin name"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="adminEmail" className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              Admin Email
            </Label>
            <Input
              id="adminEmail"
              type="email"
              value={settings.adminEmail}
              onChange={(e) => handleChange("adminEmail", e.target.value)}
              placeholder="Enter admin email"
            />
          </div>
        </div>
      </div>

      {/* Database Configuration */}
      <div className="rounded-xl border border-border bg-card p-6">
        <h3 className="mb-6 text-lg font-semibold">Database Configuration</h3>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="supabaseUrl" className="flex items-center gap-2">
              <Database className="h-4 w-4 text-muted-foreground" />
              Supabase Project URL
            </Label>
            <Input
              id="supabaseUrl"
              value={settings.supabaseUrl}
              onChange={(e) => handleChange("supabaseUrl", e.target.value)}
              placeholder="https://your-project.supabase.co"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="supabaseAnonKey" className="flex items-center gap-2">
              <Key className="h-4 w-4 text-muted-foreground" />
              Supabase Anon Key
            </Label>
            <Input
              id="supabaseAnonKey"
              type="password"
              value={settings.supabaseAnonKey}
              onChange={(e) => handleChange("supabaseAnonKey", e.target.value)}
              placeholder="Enter your Supabase anon key"
            />
          </div>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex items-center justify-between">
        {saveMessage && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-sm font-medium text-emerald-600"
          >
            {saveMessage}
          </motion.p>
        )}
        <Button
          onClick={handleSave}
          disabled={isSaving}
          className="ml-auto gap-2"
        >
          <Save className="h-4 w-4" />
          {isSaving ? "Saving..." : "Save Settings"}
        </Button>
      </div>
    </motion.div>
  )
}
