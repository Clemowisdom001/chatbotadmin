// Chat Log Types
export interface ChatLog {
  id: string
  sessionId: string
  userId: string
  question: string
  aiResponse: string | null
  department: string
  level: string
  status: "answered" | "unanswered" | "pending"
  timestamp: string
  userEmail?: string
  userPhone?: string
}

// Dashboard Stats Types
export interface DashboardStats {
  totalConversations: number
  answeredQuestions: number
  unansweredQuestions: number
  activeSessions: number
  trends: {
    totalConversations: number
    answeredQuestions: number
    unansweredQuestions: number
    activeSessions: number
  }
}

// Chart Data Types
export interface ConversationTrend {
  date: string
  total: number
  answered: number
}

export interface ResponseStatus {
  name: string
  value: number
  color: string
}

// Recent Activity Types
export interface RecentActivity {
  id: string
  question: string
  userId: string
  department: string
  timestamp: string
  status: "answered" | "unanswered" | "pending"
}

// Unanswered Question Types
export interface UnansweredQuestion {
  id: string
  sessionId: string
  question: string
  department: string
  userEmail?: string
  userPhone?: string
  timestamp: string
  status: "pending" | "contacted" | "resolved"
}

// Settings Types
export interface AdminSettings {
  adminName: string
  adminEmail: string
  supabaseUrl: string
  supabaseAnonKey: string
}
