"use client"

import { MessageSquare, CheckCircle, HelpCircle, Activity } from "lucide-react"
import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { StatCard } from "@/components/dashboard/stat-card"
import { ConversationChart } from "@/components/dashboard/conversation-chart"
import { ResponseStatusChart } from "@/components/dashboard/response-status-chart"
import { RecentActivityList } from "@/components/dashboard/recent-activity-list"
import {
  mockDashboardStats,
  mockConversationTrends,
  mockResponseStatus,
  mockRecentActivity,
} from "@/lib/mock-data"

export default function DashboardPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Dashboard Overview</h1>
          <p className="text-muted-foreground">
            Monitor your chatbot performance and analytics
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Conversations"
            value={mockDashboardStats.totalConversations}
            trend={mockDashboardStats.trends.totalConversations}
            icon={MessageSquare}
            iconColor="text-blue-600"
            iconBgColor="bg-blue-100"
          />
          <StatCard
            title="Answered Questions"
            value={mockDashboardStats.answeredQuestions}
            trend={mockDashboardStats.trends.answeredQuestions}
            icon={CheckCircle}
            iconColor="text-emerald-600"
            iconBgColor="bg-emerald-100"
          />
          <StatCard
            title="Unanswered Questions"
            value={mockDashboardStats.unansweredQuestions}
            trend={mockDashboardStats.trends.unansweredQuestions}
            icon={HelpCircle}
            iconColor="text-red-600"
            iconBgColor="bg-red-100"
          />
          <StatCard
            title="Active Sessions"
            value={mockDashboardStats.activeSessions}
            trend={mockDashboardStats.trends.activeSessions}
            icon={Activity}
            iconColor="text-amber-600"
            iconBgColor="bg-amber-100"
          />
        </div>

        {/* Charts */}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <ConversationChart data={mockConversationTrends} />
          </div>
          <div>
            <ResponseStatusChart data={mockResponseStatus} />
          </div>
        </div>

        {/* Recent Activity */}
        <RecentActivityList activities={mockRecentActivity} />
      </div>
    </DashboardLayout>
  )
}
