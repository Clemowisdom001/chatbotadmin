"use client"

import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { ChatLogsTable } from "@/components/chatlogs/chat-logs-table"
import { mockChatLogs } from "@/lib/mock-data"

export default function ChatLogsPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Chat Logs</h1>
          <p className="text-muted-foreground">
            Browse and search all chatbot conversations
          </p>
        </div>

        {/* Chat Logs Table */}
        <ChatLogsTable data={mockChatLogs} />
      </div>
    </DashboardLayout>
  )
}
