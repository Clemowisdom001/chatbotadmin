"use client"

import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { SettingsForm } from "@/components/settings/settings-form"
import { mockAdminSettings } from "@/lib/mock-data"

export default function SettingsPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground">
            Manage your admin account and database configuration
          </p>
        </div>

        {/* Settings Form */}
        <SettingsForm initialSettings={mockAdminSettings} />
      </div>
    </DashboardLayout>
  )
}
