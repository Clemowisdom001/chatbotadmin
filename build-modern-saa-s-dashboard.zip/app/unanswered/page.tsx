"use client"

import { DashboardLayout } from "@/components/layout/dashboard-layout"
import { UnansweredList } from "@/components/unanswered/unanswered-list"
import { mockUnansweredQuestions } from "@/lib/mock-data"

export default function UnansweredPage() {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Page Header */}
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Unanswered Questions</h1>
          <p className="text-muted-foreground">
            {"Manage questions the chatbot couldn't answer"}
          </p>
        </div>

        {/* Unanswered Questions List */}
        <UnansweredList questions={mockUnansweredQuestions} />
      </div>
    </DashboardLayout>
  )
}
